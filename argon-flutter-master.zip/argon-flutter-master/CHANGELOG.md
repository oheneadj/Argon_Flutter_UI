## [1.0.1] 2020-10-02
### Onboarding and Profile Screen changes
- changed backgrounds for these screens so they look fresher than ever

## [1.0.0] 2020-09-29
### Initial Release
